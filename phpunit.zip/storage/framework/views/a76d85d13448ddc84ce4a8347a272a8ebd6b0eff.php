<!DOCTYPE html>
<html>

<head>
    <title>Logs</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container">
        <h1 class="mt-5">Logs</h1>
        <div class="row mt-3">
            <div class="col-md-12">
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = explode('[', $log); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $splitLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty(trim($splitLog))): ?>
                <div class="card mb-3">
                    <div class="card-body">
                        [<?php echo e($splitLog); ?>

                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\APIRestFullBancos\resources\views/logs.blade.php ENDPATH**/ ?>